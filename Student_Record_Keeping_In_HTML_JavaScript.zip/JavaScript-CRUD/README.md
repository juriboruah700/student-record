# JavaScript-CRUD-Operation
The CRUD Operation In JavaScript is developed using JavaScript, CSS and HTML.<br>
####  CRUD stands for: Create, Read, Update and Delete.<br>
This Simple CRUD Operation In JavaScript is for adding the different records of the students. This CRUD JavaScript project uses Crud Operation for the management system as mentioned in the title itself.<br>
A CRUD Operation In JS user can add the records of many students with their name, rollno, class, address etc. Here, the user can add the data, delete the data whenever they want, and also edit the records details if they have to update some data. This CRUD Operation In JavaScript Example includes a lot of JavaScript for making validations to certain parts of the project CRUD Operation Using JavaScript.<br>
To start creating a CRUD Operation In JavaScript, makes sure that you have any platform in creating a JavaScript, CSS and HTML installed in your computer, in my case I will use <a href="https://code.visualstudio.com/download">VSCODE</a>.<hr>

###  Steps on how to create a CRUD Operation In JavaScript<br>
<ul>
	<li><b> Step 1: Open VSCODE Text:</b>First after installing vscode, click “open” to start.</li>
	<li><b> Step 2: Create a HTML file:</b>Second click "file" and select "save as" and named it "index.html".</li>
	<li><b> Step 3: Create a CSS file:</b>Third click "file" and select "save as" and named it "style.css"</li>
	<li><b> Step 4: Create a JavaScript file:</b> Fourth click "file: and select "save as" and named it "script.js"</li>
	<li><b> Step 5: The actual code:</b>You are free to copy the code  and paste to your different file created.</li>
</ul>
 
